fixture: the files are unpacked into unpacked/8053/
